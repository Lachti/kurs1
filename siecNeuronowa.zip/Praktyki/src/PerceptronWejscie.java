
public class PerceptronWejscie {

	double[] tabwag = null;
		
	public PerceptronWejscie(int liczbawag) {
		tabwag = new double[liczbawag];
		
		for(int i=0; i<tabwag.length; i++) {
			tabwag[i] = Math.random()*1.0;
		}				
	}
	
	
}
