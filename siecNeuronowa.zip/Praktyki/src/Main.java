import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Map<Integer, int[]> mapaOutput = new LinkedHashMap<>();		
			mapaOutput.put(1, new int[] {0, 0, 0, 0, 0});
			mapaOutput.put(2, new int[] {0, 0, 0, 0, 1});
			mapaOutput.put(3, new int[] {0, 0, 0, 1, 0});
			mapaOutput.put(4, new int[] {0, 0, 0, 1, 1});
			mapaOutput.put(5, new int[] {0, 0, 1, 0, 0});
			mapaOutput.put(6, new int[] {0, 0, 1, 0, 1});
			mapaOutput.put(7, new int[] {0, 0, 1, 1, 0});
			mapaOutput.put(8, new int[] {0,0,1,1,1});
			mapaOutput.put(9, new int[] {0,1,0,0,0});
			mapaOutput.put(10, new int[] {0,1,0,0,1});
			mapaOutput.put(11, new int[] {0, 1, 0, 1, 0});
			mapaOutput.put(12, new int[] {0,1,0,1,1});
			mapaOutput.put(13, new int[] {0,1,1,0,0});
			mapaOutput.put(14, new int[] {0,1,1,0,1});
			mapaOutput.put(15, new int[] {0,1,1,1,0});
			mapaOutput.put(16, new int[] {0,1,1,1,1});
			mapaOutput.put(17, new int[] {1,0,0,0,0});
			mapaOutput.put(18, new int[] {1,0,0,0,1});
			mapaOutput.put(19, new int[] {1,0,0,1,0});
			mapaOutput.put(20, new int[] {1,0,0,1,1});
			mapaOutput.put(21, new int[] {1,0,1,0,0});
			mapaOutput.put(22, new int[] {1,0,1,0,1});
			mapaOutput.put(23, new int[] {1,0,1,1,0});
			mapaOutput.put(24, new int[] {1,0,1,1,1});
			mapaOutput.put(25, new int[] {1,1,0,0,0});
			mapaOutput.put(26, new int[] {1,1,0,0,1});
			mapaOutput.put(27, new int[] {1,1,0,1,0});
			mapaOutput.put(28, new int[] {1,1,0,1,1});
			mapaOutput.put(29, new int[] {1,1,1,0,0});
		
		Map<int[], Integer>	 mapaprzeciwna = new LinkedHashMap<>();	
			
		for (Map.Entry<Integer, int[]> entry : mapaOutput.entrySet()){
		    mapaprzeciwna.put(entry.getValue(), entry.getKey());
		}
				
		double lr = 0.01;	/*tutaj mozna zmieniac wspolczynnik uczenia*/
			
		double[][] tabdanych = 	dataConvert(wczytywanieDanych("src/abalonepodzielone.data.txt"));
			
		int tabwymiarow[] = dataSize("src/abalonepodzielone.data.txt");
		
		int liczbaNeuronowWarstwyUkrytej = 12;
		
		int liczbaNeuronowWarstwyWyjsciowej = 5;
		
		int liczbazmiennychuczacych = tabwymiarow[1]-1;
		
		double [] tablicaoutputowpierwszejwarstwy = new double[liczbazmiennychuczacych];
		
		double [] tablicaoutputowukrytejwarstwy = new double[liczbaNeuronowWarstwyUkrytej];
		
		double [] tablicaoutputowwyjsciowejwarstwy = new double[liczbaNeuronowWarstwyWyjsciowej];
								
		double[][] wagiNeuronowWejsciowej = tworzenieNeuronow(liczbazmiennychuczacych,liczbazmiennychuczacych);
				
		double[][] wagiNeutronowUkrytej = tworzenieNeuronow(liczbaNeuronowWarstwyUkrytej,tablicaoutputowpierwszejwarstwy.length);
				
		double[][] wagiNeutronowWyjscia = tworzenieNeuronow(liczbaNeuronowWarstwyWyjsciowej,tablicaoutputowukrytejwarstwy.length);
		
	

		long startTime = System.currentTimeMillis();
		
		while(false||(System.currentTimeMillis()-startTime)<5000) {
	        
				for(int p=0; p<tabdanych.length; p++) {		/* tutaj ustalam ile ma sie uczy� w moim przypadku jest to tylko jednorazowe przeanalizowanie danych uczacych*/
	        	
											
						for(int k=0; k<liczbazmiennychuczacych; k++) {		/*zapisywanie outputow warstwy wejsciowej*/
									
							double net = liczenieNET(wagiNeuronowWejsciowej[k], tabdanych[p], liczbazmiennychuczacych);								
							double outputperceptrona1 = funkcjaAktywacjaUnipolarna(net);						
							tablicaoutputowpierwszejwarstwy[k] = outputperceptrona1;				
						}
						
						for(int k=0; k<liczbaNeuronowWarstwyUkrytej; k++) {		/*zapisywanie outputow warstwy ukrytej*/
									
							double net = liczenieNET(wagiNeutronowUkrytej[k], tablicaoutputowpierwszejwarstwy, tablicaoutputowpierwszejwarstwy.length);		
							double outputperceptrona1 = funkcjaAktywacjaUnipolarna(net);		
							tablicaoutputowukrytejwarstwy[k] = outputperceptrona1;
						}			
						
						for(int k=0; k<liczbaNeuronowWarstwyWyjsciowej; k++) {	/*zapisywanie outputow warstwy wyjsciowej*/
						
							double net = liczenieNET(wagiNeutronowWyjscia[k], tablicaoutputowukrytejwarstwy, tablicaoutputowukrytejwarstwy.length);		
							double outputperceptrona1 = funkcjaAktywacjaUnipolarna(net);			
							tablicaoutputowwyjsciowejwarstwy[k] = outputperceptrona1;		
						}
						
																		
						int[] tabodczytana = mapaOutput.get((int)tabdanych[p][liczbazmiennychuczacych]);
								
																
						double[] tablicaKorektWagWyjsciowej = new double [liczbaNeuronowWarstwyWyjsciowej];		/*Tutaj obliczam korekte wag Wyjsciowej*/
									
						for (int k=0; k<liczbaNeuronowWarstwyWyjsciowej; k++) {
									
							for(int i=0; i<liczbaNeuronowWarstwyUkrytej; i++) {
							
								double korektawagi = 0;
								
								korektawagi = lr * (tabodczytana[k] - tablicaoutputowwyjsciowejwarstwy[k]) * tablicaoutputowukrytejwarstwy[i];
											
								tablicaKorektWagWyjsciowej[k] += korektawagi;
							}	
						
						}
						
							
						double[] tablicaKorektWagUkrytej = new double [liczbaNeuronowWarstwyUkrytej];	/*Tutaj obliczam korekte wag Ukrytej*/
						
						for(int k=0; k<liczbaNeuronowWarstwyUkrytej; k++) {
							
								double korektawagi = 0;
								
								for(int i=0; i<tablicaKorektWagWyjsciowej.length; i++) {
									
									korektawagi += lr * tablicaKorektWagWyjsciowej[i] * wagiNeutronowWyjscia[i][k] ; 
									
									tablicaKorektWagUkrytej[k] += korektawagi;
								}
						}
								
						
						double[] tablicaKorektWagWejsciowej = new double [liczbazmiennychuczacych];		/*Tutaj obliczam korekte wag Wejsciowej*/
						
						for(int k=0; k<liczbazmiennychuczacych; k++) {
							
								double korektawagi = 0;
						
								for(int i=0; i<tablicaKorektWagUkrytej.length; i++) {
									
									korektawagi += lr * tablicaKorektWagUkrytej[i] * wagiNeutronowUkrytej[i][k];
									
									tablicaKorektWagWejsciowej[k] += korektawagi;
								}
						}
					
																								
						wagiNeuronowWejsciowej = dodanieWag(wagiNeuronowWejsciowej, tablicaKorektWagWejsciowej);
						
						wagiNeutronowUkrytej = dodanieWag(wagiNeutronowUkrytej, tablicaKorektWagUkrytej);

						wagiNeutronowWyjscia = dodanieWag(wagiNeutronowWyjscia, tablicaKorektWagWyjsciowej);
												
				}
		}	

		
		/*Tutaj jest Testowanie*/		
				
				double[] tabDanychTesttowych = {1.0, 0.71, 0.555, 0.195, 0.0005, 0.9455, 0.3765, 0.1};	/* Mozna podac dowolna tablice 8 elementowa� do testowania*/
				
				double [] tablicaoutputowpierwszejwarstwyTest = new double[liczbazmiennychuczacych];
				
				double [] tablicaoutputowukrytejwarstwyTest = new double[liczbaNeuronowWarstwyUkrytej];
				
				double [] tablicaoutputowwyjsciowejwarstwyTest = new double[liczbaNeuronowWarstwyWyjsciowej];
				
				
				for(int k=0; k<liczbazmiennychuczacych; k++) {		/*zapisywanie outputow warstwy wejsciowej*/
					
					double net = liczenieNET(wagiNeuronowWejsciowej[k], tabDanychTesttowych, liczbazmiennychuczacych);								
					double outputperceptrona1 = funkcjaAktywacjaUnipolarna(net);						
					tablicaoutputowpierwszejwarstwyTest[k] = outputperceptrona1;				
				}
				
				for(int k=0; k<liczbaNeuronowWarstwyUkrytej; k++) {		/*zapisywanie outputow warstwy ukrytej*/
							
					double net = liczenieNET(wagiNeutronowUkrytej[k], tablicaoutputowpierwszejwarstwyTest, tablicaoutputowpierwszejwarstwyTest.length);		
					double outputperceptrona1 = funkcjaAktywacjaUnipolarna(net);		
					tablicaoutputowukrytejwarstwyTest[k] = outputperceptrona1;
				}			
				
				for(int k=0; k<liczbaNeuronowWarstwyWyjsciowej; k++) {	/*zapisywanie outputow warstwy wyjsciowej*/
				
					double net = liczenieNET(wagiNeutronowWyjscia[k], tablicaoutputowukrytejwarstwyTest, tablicaoutputowukrytejwarstwyTest.length);		
					double outputperceptrona1 = funkcjaAktywacjaUnipolarna(net);			
					tablicaoutputowwyjsciowejwarstwyTest[k] = outputperceptrona1;		
				}
				
				
				
				int[] tabjednostek = new int[liczbaNeuronowWarstwyWyjsciowej];
				
				for(int i=0; i<tabjednostek.length; i++) {					
					if(1-tablicaoutputowwyjsciowejwarstwyTest[i]>0.5) {
						tabjednostek[i] = 0;
					}else {
						tabjednostek[i] = 1;
					}						
				}
				
								
				for (Map.Entry<int[], Integer> entry : mapaprzeciwna.entrySet()){				    
					if(Arrays.equals(entry.getKey(), tabjednostek)) {
						System.out.println(entry.getValue());
						System.out.println("Wiec wiek wynosi: "+entry.getValue()/1.5);
					}								    
				}
				
			
				
		/*Koniec testowania*/	
	
		
	}
	
	
	
	
	public static double[][] dodanieWag(double[][] tab1, double[] tab2){	/*dodaj korekte wag do neuronow */
		
		for(int i=0; i<tab1.length; i++) {		
			for(int j=0; j<tab1[i].length; j++) {				
				tab1[i][j] += tab2[i];				
			}
		}		
		return tab1;
	}
			
	public static double[][] tworzenieNeuronow(int parametr1, int parametr2){
			
		double[][] wagiNeutronow = new double[parametr1][parametr2];
		
		for(int k=0; k<parametr1; k++) {					
			PerceptronWejscie percptronwej = new PerceptronWejscie(parametr2);		
			wagiNeutronow[k] = percptronwej.tabwag;						
		}
	
		return wagiNeutronow;
	}
			
	public static Double funkcjaAktywacjaUnipolarna(Double net) {
		
		Double wartoscFuinkcjiAktywacji = 1.0/(1.0+Math.pow(Math.E, -net));						
		return wartoscFuinkcjiAktywacji;
	}
		
	public static double liczenieNET(double[] tabwag, double[] dane, int liczbazmiennychuczacych) {
		
		double net = 0;
		
		for(int i=0; i<liczbazmiennychuczacych; i++) {
			net += tabwag[i]*dane[i];
		}
		
		return net;
	}
		
	public static String[][] wczytywanieDanych(String adrespliku) {
				
		int[] tablicarozmiarow = dataSize(adrespliku);		
		String tabdanych[][] = new String[tablicarozmiarow[0]][tablicarozmiarow[1]]; 			
		String thisLine = null;
		
		try {
	         
			FileReader fileReader = new FileReader(adrespliku); 
			BufferedReader br = new BufferedReader(fileReader);
	        int i = 0; 
			
	        	while ((thisLine = br.readLine()) != null) {
	            
	        		String[] tabsplit = thisLine.split("\\s+");	        	 	        	 	        	
	        		tabdanych[i] = tabsplit;	        	 
	        		i++;	        	         	 
	        	}       	         
	      } catch(Exception e) {
	         e.printStackTrace();
	      }		
		return tabdanych;
	
	}	
	
	public static int[] dataSize(String adrespliku) {
		
		int tablicawymiarow[] = new int[2];
		String thisLine = null;
		int lineCounter = 0;
		int dlugosclini = 0;
		boolean flag = true;
		
			try {		         
					FileReader fileReader = new FileReader(adrespliku); 
					BufferedReader br = new BufferedReader(fileReader);
		         
					while ((thisLine = br.readLine()) != null) {	            
						if(flag){
							String[] tabsplit = thisLine.split("\\s+");	        	 	        	 
							lineCounter++; 
							dlugosclini = tabsplit.length;
							flag = false;
						}else {							        	 	        	 
							lineCounter++;
						}						
		        }       	   
									
				tablicawymiarow[0] = lineCounter;
				tablicawymiarow[1] = dlugosclini;
					
		    } catch(Exception e) {
		         e.printStackTrace();
		    }
						
		return tablicawymiarow;
	}
	
	public static double[][] dataConvert(String[][] tabStringow) {
		
		Map<String, Double> mapa = new HashMap<>();
			mapa.put("M", 1.0);
			mapa.put("F", 2.0);
			mapa.put("I", 3.0);
		
		double[][] tabdouble = new double[tabStringow.length][tabStringow[0].length];
						
		for(int i=0; i<tabStringow.length; i++) {
			
			tabdouble[i][0] = mapa.get(tabStringow[i][0]);
			
			for(int j=1; j<tabStringow[i].length; j++) {								
				tabdouble[i][j] = Double.parseDouble(tabStringow[i][j].replace(",", "."));			
			}			
		}									
		return tabdouble;
	}
	




}
